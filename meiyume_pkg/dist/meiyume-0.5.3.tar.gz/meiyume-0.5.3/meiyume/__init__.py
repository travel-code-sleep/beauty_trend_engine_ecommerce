from __future__ import absolute_import

def main():
    import meiyume 
    import meiyume.sph_crawler
    import meiyume.sph_master
    import meiyume.utils

if __name__ == '__main__':
    main()